/*
 * TPL1-B-Secuencia.c
 */
#include "Infotronic.h"

void Secuencia ( void )
{
	static char cont = 0 , fcont = 0;

	if ( ( ( FIO2PIN >> 13 ) & 1 ) == 1 && fcont == 0 )
	{
		FIO0PIN	 = FIO0PIN	 & ~( 1 << 22 ) ;
		fcont = 1;
	}

	if ( ( ( FIO2PIN >> 13 ) & 1 ) == 0 && fcont == 1 )
	{
		FIO0PIN	 = FIO0PIN	 | ( 1 << 22 ) ;
		cont ++;
		fcont = 0;
	}
}
