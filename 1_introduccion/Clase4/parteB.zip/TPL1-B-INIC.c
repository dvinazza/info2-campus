/*
 * TPL1-B-INIC.c
 */

#include "Infotronic.h"

void Inicializar ( void )
{
	InitPLL (  );
	InitGPIOs (  );
}

void InitGPIOs ( void )
{
	PINSEL0_H = PINSEL0_H & ( ~ ( 3 << ( 22 % 16 ) * 2 ) );
	PINSEL0_H = PINSEL0_H | ( 0 << ( 22 % 16 ) * 2 );

	FIO0DIR	= FIO0DIR | ( 1 << 22 );

	PINSEL0_L = PINSEL0_L & ( ~ ( 3 << ( 13 % 16 ) * 2 ) ) ;
	PINSEL0_L = PINSEL0_L | ( 0 << ( 13 % 16 ) * 2 ) ;

	FIO0DIR	= FIO0DIR & ( ~ ( 1 << 13 ) ) ;
}
