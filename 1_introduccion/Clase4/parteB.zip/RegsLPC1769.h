#ifndef REGS_H_
#define REGS_H_

	#define		__R					volatile const
	#define		__W					volatile
	#define		__RW				volatile

	typedef 	unsigned int 		uint32_t;
	typedef 	unsigned short 		uint16_t;
	typedef 	unsigned char 		uint8_t;


	//!< GPIO - PORT0
	/*	*						*
		*************************
		*		FIODIR			*	0x2009C000
		*************************
		*		RESERVED		*	0x2009C004
		*************************
		*		RESERVED		*	0x2009C008
		*************************
		*		RESERVED		*	0x2009C00C
		*************************
		*		FIOMASK			*	0x2009C010
		*************************
		*		FIOPIN			*	0x2009C014
		*************************
		*		FIOSET			*	0x2009C018
		*************************
		*		FIOCLR			*	0x2009C01C
		*************************
		*						*
		*						*
	*/

	//!< P0
	#define		PINSEL0_L	( * ( ( __RW uint32_t * ) 0x4002C000UL ) )
	#define		PINSEL0_H	( * ( ( __RW uint32_t * ) 0x4002C004UL ) )


	#define		FIO0DIR		( * ( ( __RW uint32_t * ) 0x2009C000UL ) )
	#define		FIO0MASK	( * ( ( __RW uint32_t * ) 0x2009C010UL ) )
	#define		FIO0PIN		( * ( ( __RW uint32_t * ) 0x2009C014UL ) )
	#define		FIO0SET		( * ( ( __RW uint32_t * ) 0x2009C018UL ) )
	#define		FIO0CLR		( * ( ( __W uint32_t *  ) 0x2009C01CUL ) )

	//!< P0
	#define		PINSEL2_L	( * ( ( __RW uint32_t * ) 0x4002C010UL ) )

	#define		FIO2DIR		( * ( ( __RW uint32_t * ) 0x2009C040UL ) )
	#define		FIO2MASK	( * ( ( __RW uint32_t * ) 0x2009C050UL ) )
	#define		FIO2PIN		( * ( ( __RW uint32_t * ) 0x2009C054UL ) )
	#define		FIO2SET		( * ( ( __RW uint32_t * ) 0x2009C058UL ) )
	#define		FIO2CLR		( * ( ( __W uint32_t *  ) 0x2009C05CUL ) )
	//PINMODE4 - address 0x4002 C050)

	#define		RGBR		PORT2,1			//GPIO2
	#define		RGBG		PORT2,2			//GPIO2
	#define		RGBB		PORT2,3			//GPIO2
	//!< ///////////////////   PCONP   //////////////////////////
	//!<  Power Control for Peripherals register (PCONP - 0x400F C0C4) [pag. 62 user manual LPC1769]
	//!< 0x400FC0C4UL : Direccion de inicio del registro de habilitación de dispositivos:
	#define 	PCONP	(* ( ( __RW uint32_t  * ) 0x400FC0C4UL ))


	//!< ///////////////////   PCLKSEL   //////////////////////////
	//!< Peripheral Clock Selection registers 0 and 1 (PCLKSEL0 -0x400F C1A8 and PCLKSEL1 - 0x400F C1AC) [pag. 56 user manual]
	//!< 0x400FC1A8UL : Direccion de inicio de los registros de seleccion de los CLKs de los dispositivos:
	#define		PCLKSEL		( ( __RW uint32_t  * ) 0x400FC1A8UL )
	//!< Registros PCLKSEL
	#define		PCLKSEL0	PCLKSEL[0]
	#define		PCLKSEL1	PCLKSEL[1]

#endif /* REGS_H_ */
