/*
 * TPL1-INIC.c
 *
 *  Created on: 17/01/2014
 *      Author: marcelo
 */
#include "Infotronic.h"
void Inicializar ( void )
{
	InitPLL (  );
	InitGPIOs (  );
}

void InitGPIOs ( void )
{
	PINSEL0_H = PINSEL0_H & ( ~ ( 3 << ( 22 % 16 ) * 2 ) );
	PINSEL0_H = PINSEL0_H | ( 0 << ( 22 % 16 ) * 2 );

	FIO0DIR	= FIO0DIR | ( 1 << 22 );
}
