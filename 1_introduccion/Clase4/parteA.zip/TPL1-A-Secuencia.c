/*
===============================================================================
 Name        : main.c
 Author      : $(author)
 Version     :
 Copyright   : $(copyright)
 Description : main definition
===============================================================================
*/


#include "Infotronic.h"

void Secuencia ( void )
{
	static uint8_t bit = 0 ;

	if ( bit )
		FIO0PIN	 = FIO0PIN	 & ~( 1 << 22 ) ;
	else
		FIO0PIN	 = FIO0PIN	 | ( 1 << 22 ) ;

	bit++ ;
	bit %= 2 ;
}
