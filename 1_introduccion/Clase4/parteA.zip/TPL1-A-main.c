/*
===============================================================================
 Name        : main.c
 Author      : $(author)
 Version     :
 Copyright   : $(copyright)
 Description : main definition
===============================================================================
*/


#include "Infotronic.h"

int main(void)
{
	Inicializar ( ) ;

	while (1)
		Secuencia ( );

    return 0 ;
}
