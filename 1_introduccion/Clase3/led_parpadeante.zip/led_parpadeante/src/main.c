
#include <cr_section_macros.h>
#include <NXP/crp.h>

#define 	__RW				volatile
typedef 	unsigned int 		uint32_t;
typedef 	__RW uint32_t 		registro;

#define	    PORT0 		( ( registro  * ) 0x2009C000UL )
#define		PINSEL		( ( registro  * ) 0x4002C000UL )


int main(void)
	{
	
	PINSEL[1] &= ~(0x03 << (6 * 2)); // Con esta linea y la siguiente
	PINSEL[1] |= (0 << (6 * 2)); // configuro el modo del pin (el pin 22), sin afectar el estado
								 // en el que estaban los demás. Lo configuro como GPIO

	PORT0 [0] |= ( 0x01 << 22 ); // En esta línea configuro el pin 22 del puerto 0 como salida.

	while(1) {
	PORT0[6] |= ( 0x01 << 22 ); //  prendo el led -- seteo el bit correspondiente de FIOSET.
	//PORT0[7] |= ( 0x01 << 22 ); //	apago el led -- seteo el bit correspondiente de FIOCLR.
			 }
	return 0 ;
	}
