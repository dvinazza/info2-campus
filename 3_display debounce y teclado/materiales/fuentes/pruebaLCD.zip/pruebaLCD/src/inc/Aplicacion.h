/*
 * Aplicacion.h
 *
 *  Created on: 07/09/2013
 *      Author: marcelo
 */

#ifndef APLICACION_H_
#define APLICACION_H_

	#include "FW_Display-Expansion2.h"
	#include "FW_GPIO.h"
	#include "KitInfo2_BaseBoard.h"
	#include "Oscilador.h"
	#include "RegsLPC1769.h"
	#include "Entradas.h"

	void cuentoPulsos (void);
	void InicializarKit ( void );

#endif /* APLICACION_H_ */
