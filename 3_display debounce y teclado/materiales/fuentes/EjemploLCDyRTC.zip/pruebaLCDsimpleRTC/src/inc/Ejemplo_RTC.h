/**
 \file		: Ejemplo_RTC.h
 \brief     : Header de ejemplo RTC
 \details   :
 \author    : GOS
 \date 	    : 2014.06.08
*/


#ifndef EJEMPLO_RTC_H_
#define EJEMPLO_RTC_H_

#define LCD_ANCHO	16

void Inic(void);
void Display_HoraFecha(void);

#endif /* EJEMPLO_RTC_H_ */
