
#include "Infotronic.h"

/********************************************************************************
	\fn  void Inicializar ( void )
	\brief Inicializacion de Hardware.
	\author & date: Informática II
 	\param void
	\return:	void
*/
void Inicializar ( void )
{
	InitPLL ( ) ;
	InicSysTick ( );
	InitExpansion();
}

/********************************************************************************
	\fn  void InicSysTick ( void )
	\brief Inicialización de Interrupcion Systick.
	\author & date: Informática II
 	\param void
	\return:	void
*/
void InicSysTick ( void )
{
	STRELOAD = ( STCALIB / 4) - 1;	// Recarga cada 2.5 ms
	STCURR = 0;	// Cargando con cero limpio y provoco el disparo de una intrrupcion
	// Habilito el conteo
	// Habilito interrupcion
	// Utilizamos Pclk
	STCTRL |=  ( ( 1 << ENABLE ) | ( 1 << TICKINT ) | ( 1 << CLKSOURCE ) );
}

void InitExpansion(void)
{
	// elección de GPIO - PINSEL
	// a, b, c, d, e, f, g, dp
	// común dígito 0, común dígito 1, común dígito 2
	// común dígito 3, común dígito 4, común dígito 5

	// Configuración de los puertos - FIODIR
	// a, b, c, d, e, f, g, dp
	// común dígito 0, común dígito 1, común dígito 2
	// común dígito 3, común dígito 4, común dígito 5
}
