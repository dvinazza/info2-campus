#include "Infotronic.h"

extern uint8_t Buff_Display [];

void DriverDisplay (void)
{
	// Apagado de los dígitos 0,1,2,3,4 y 5

	// Encendido de los segmentos a, b, c, d, e, f y g

	// Selección del digito a encender ( cíclico en modulo 6 )
}

void DriverTeclado ( void )
{
	// Lectura de los pulsadores
	// Eliminación del rebote de los pulsadores
}


