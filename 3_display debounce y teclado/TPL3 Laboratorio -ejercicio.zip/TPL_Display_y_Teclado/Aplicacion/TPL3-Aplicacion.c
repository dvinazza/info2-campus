#include "Infotronic.h"


uint8_t Buff_Display [CANT_DIGITOS];


int main(void)
{
	
	// Mostrar en el display el valor 123456

	return 0 ;
}


