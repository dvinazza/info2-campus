/*
 * Display_7_seg.c
 *
 *  Created on: 04/06/2014
 *      Author: Hernan
 */
#include "RegsLPC1769.h"
#include "Infotronic.h"

extern uint8_t Buff_Display [] ;


unsigned char Tabla_Digitos_BCD_7seg[] = { 0x3f, 0x06, 0x5B, 0x4f, 0x66, 0x6D, 0x7C, 0x07, 0x7f, 0x67};

void Display7seg ( uint32_t valor  )
{

}


uint8_t Tecla ( void )
{
	// leer buffer
	// borrar buffer
	// retornar código de tecla
}

