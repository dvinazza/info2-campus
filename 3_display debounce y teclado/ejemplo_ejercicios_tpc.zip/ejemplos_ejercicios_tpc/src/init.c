#include "myreg.h"

void init(void)
{
	Init_GPIO();
	Init_IntExt();
}

void Init_GPIO(void)
{
	// Completar inicialización!
}

void Init_IntExt(void)
{
	// Completar inicialización!
}

