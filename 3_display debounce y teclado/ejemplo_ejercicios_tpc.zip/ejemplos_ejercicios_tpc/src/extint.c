#include "myreg.h"

// flag INTEXT, la escribo desde la ISR y la limpio desde el main
uint32_t flag_int_externa = FALSE;

void EINT0_IRQHandler(void)
{
	static uint32_t secuencia = 0;	// variable para la secuencia de 4 leds

	EXTINT = 0x0F; 		// Limpio los flags de las interrupciones poniendo un UNO.

	switch (secuencia) {
		case 0:
			SetPIN(PORT1, 3, OFF);
			SetPIN(PORT1, 0, ON);
			break;
		case 1:
			SetPIN(PORT1, 0, OFF);
			SetPIN(PORT1, 1, ON);
			break;
		case 2:
			SetPIN(PORT1, 1, OFF);
			SetPIN(PORT1, 2, ON);
			break;
		case 3:
			SetPIN(PORT1, 2, OFF);
			SetPIN(PORT1, 3, ON);
			break;
	}
	secuencia ++;		// incremento el valor de secuencia (0,1,2,3)
	if (secuencia > 3)	// chequeo si llegué al último led
		secuencia = 0;
}

void EINT3_IRQHandler(void)
{
	EXTINT = 0x0F; 		// Limpio los flags de las interrupciones poniendo un UNO.

	flag_int_externa = TRUE;	// solamente levanto el flag
}
