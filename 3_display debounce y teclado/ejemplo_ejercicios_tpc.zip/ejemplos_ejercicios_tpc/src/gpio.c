#include "myreg.h"

void SetPINSEL (uint8_t puerto, uint8_t pin, uint8_t modo)
{
	switch (puerto) {
		case P0:
			if (pin >= 16){
				pin -=16;
				PINSEL1 &= ~(0x03 << (pin * 2));
				PINSEL1 |= (modo << (pin * 2));
			}
			else {
				PINSEL0 &= ~(0x03 << (pin * 2));
				PINSEL0 |= (modo << (pin * 2));
			}
			break;

		case P1:
			if (pin >= 16){
				pin -=16;
				PINSEL3 &= ~(0x03 << (pin * 2));
				PINSEL3 |= (modo << (pin * 2));
			}
			else{
				PINSEL2 &= ~(0x03 << (pin * 2));
				PINSEL2 |= (modo << (pin * 2));
			}
			break;

		case P2:
			if (pin >= 16){
				pin -=16;
				PINSEL5 &= ~(0x03 << (pin * 2));
				PINSEL5 |= (modo << (pin * 2));
			}
			else{
				PINSEL4 &= ~(0x03 << (pin * 2));
				PINSEL4 |= (modo << (pin * 2));
			}
			break;

		case P3:
			if (pin >= 16){
				pin -=16;
				PINSEL7 &= ~(0x03 << (pin * 2));
				PINSEL7 |= (modo << (pin * 2));
			}
			else{
				PINSEL6 &= ~(0x03 << (pin * 2));
				PINSEL6 |= (modo << (pin * 2));
			}
			break;

		case P4:
			if (pin >= 16){
				pin -=16;
				PINSEL9 &= ~(0x03 << (pin * 2));
				PINSEL9 |= (modo << (pin * 2));
			}
			else{
				PINSEL8 &= ~(0x03 << (pin * 2));
				PINSEL8 |= (modo << (pin * 2));
			}
			break;
	} //fin switch
}

void SetDIR(registro* puerto,uint8_t pin,uint8_t direccion)
{
	( direccion == 1 ) ? ( puerto[0] |= ( 0x01 << pin ) ):( puerto[0] &= ~( 0x01 << pin ) );
}

void SetPIN(registro* puerto,uint8_t pin,uint8_t estado)
{
	( estado == 1 ) ? ( puerto[6] |= ( 0x01 << pin ) ):( puerto[7] |= ( 0x01 << pin ) );
}

uint8_t GetPIN(registro* puerto, uint8_t pin)
{
	return (puerto[5]>>pin)& 0x01;	//puerto[5] == FIOPIN
}

uint8_t isActivo (registro* puerto, uint8_t pin, uint8_t actividad)
{
	uint8_t estado;

	estado = ( puerto[5] >> pin ) & 0x01; //puerto[5] == FIOPIN

	if (estado == actividad)
		return TRUE;
	else
		return FALSE;
}

uint8_t isActivo_v2 (registro* puerto, uint8_t pin, uint8_t actividad)
{
	// puerto[5] == FIOPIN (ver mapa de memoria I/O)
	return ( ( ( puerto[5] >> pin ) & 0x01 ) == actividad ) ? 1 : 0;
}

/*
 * \fn  uint8_t isActivo( uint8_t puerto , uint8_t pin , uint8_t actividad )
 * \brief Devuelve el ESTADO de un determinado PIN de un determinado PUERTO
 * \param [in] puerto: PUERTO con el que se va a trabajar
 * \param [in] pin:	PIN a consultar
 * \param [in] actividad:	ACTIVO_ALTO = 1, ACTIVO_BAJO = 0
 * \return:	estado del pin consultado (uint_8)
 */
uint8_t isActivo_v3 (uint8_t puerto, uint8_t pin, uint8_t actividad)
{
	puerto = puerto * 8 + 5;	// ubico el registro FIOPIN del puerto

	return ( ( ( GPIOs[ puerto ] >> pin ) & 0x01 ) == actividad ) ? 1 : 0;

}

uint8_t isActivo_v4 (uint8_t puerto, uint8_t pin, uint8_t actividad)
{
	uint8_t estado;

	puerto = puerto * 8 + 5;	// offset para acceder al registro FIOPIN del puerto

	estado = ( GPIOs[ puerto ] >> pin ) & 0x01;

	if (estado == actividad)
		return 1;
	else
		return 0;
}
