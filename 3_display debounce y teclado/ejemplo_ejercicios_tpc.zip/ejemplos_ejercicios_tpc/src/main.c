
#include <cr_section_macros.h>
#include <NXP/crp.h>
#include "myreg.h"

// defines para usar la función isActivo(port, pin, actividad)
#define 	PULSADOR1	PORT0, 18, ACTIVO_BAJO
#define		SWITCH2		PORT1, 26, ACTIVO_ALTO

// flag para detectar que llegó una interrupción externa
extern uint32_t flag_int_externa;

// estructura con campos de bits
union u_bits {
	uint8_t byte;		// 8 bits
	struct campo_bits {
		uint8_t bit_0: 1;
		uint8_t bit_1: 1;
		uint8_t bit_2: 1;
		uint8_t bit_3: 1;
		uint8_t bit_4: 1;
		uint8_t bit_5: 1;
		uint8_t bit_6: 1;
		uint8_t bit_7: 1;
	} bits;
};

int main(void)
	{
	uint8_t valor = 0x35;

	init();

	while(1)
	{
		// pruebo las funciones...
		compuertaAND();
		compuertaAND_v2();
		valor = transponer(valor);
		valor = transponer_v2(valor);

		if ( isActivo(PULSADOR1) ) {
			// hago algo...
		}

		if ( isActivo_v2(SWITCH2) ) {
			// hago algo...
		}

		if (flag_int_externa == TRUE) {
			flag_int_externa = FALSE;		// limpio el flag
			// secuencia de leds 1,2,3,4...
		}

	}

	return 0 ;
}

void compuertaAND(void)
{
	uint8_t entrada_A, entrada_B;

	entrada_A = GetPIN(PORT1, 22);
	entrada_B = GetPIN(PORT1, 19);

	if (entrada_A == 1 && entrada_B == 1)
		SetPIN(PORT0, 7, 1);	// Z = 1
	else
		SetPIN(PORT0, 7, 0);	// Z = 0
}
void compuertaAND_v2(void)
{
	SetPIN(PORT0, 7, ( GetPIN(PORT1, 22) & GetPIN(PORT1, 19) )); // Z = A & B
}

uint8_t transponer(uint8_t dato)
{
	uint8_t dato_aux = 0x00;
	uint8_t i;

	for (i=0; i < 8; i++) {
		dato_aux |= (((dato >> i) & (0x01)) << (7-i));
	}

	return dato_aux;
}

uint8_t transponer_v2(uint8_t dato)
{
	union u_bits dato_aux;
	dato_aux.byte = dato;
	uint8_t bit_aux;

	bit_aux = dato_aux.bits.bit_0;
	dato_aux.bits.bit_0 = dato_aux.bits.bit_7;
	dato_aux.bits.bit_7 = bit_aux;

	bit_aux = dato_aux.bits.bit_1;
	dato_aux.bits.bit_1 = dato_aux.bits.bit_6;
	dato_aux.bits.bit_6 = bit_aux;

	bit_aux = dato_aux.bits.bit_2;
	dato_aux.bits.bit_2 = dato_aux.bits.bit_5;
	dato_aux.bits.bit_5 = bit_aux;

	bit_aux = dato_aux.bits.bit_3;
	dato_aux.bits.bit_3 = dato_aux.bits.bit_4;
	dato_aux.bits.bit_4 = bit_aux;

	return dato_aux.byte;
}

