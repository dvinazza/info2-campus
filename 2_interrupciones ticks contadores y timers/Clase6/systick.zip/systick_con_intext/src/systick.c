#include "myreg.h"

void SysTick_Handler(void)
{
static uint8_t decimas = 10;
static uint8_t segundos = 60;
static uint8_t minutos = 60;
static uint8_t horas = 24;


Funciones_decimas();
decimas --;
if(!decimas)
{
	decimas = 10;
	segundos --;
	Funciones_segundos();
}
if(!segundos)
{
	segundos = 60;
	minutos --;
	Funciones_minutos();
}
if(!minutos)
{
	minutos = 60;
	horas --;
	Funciones_horas();
}
if(!horas)
{
	horas = 24;
	Funciones_dias();
}

}

void Funciones_decimas(void)
{
	if(GetPIN(PORT0,27))
	{
		SetPIN(PORT0,27,0);
		SetPIN(PORT0,21,0);
		SetPIN(PORT0,23,0);
		SetPIN(PORT2,0,0);
	}
	else
	{
		SetPIN(PORT0,27,1);
		SetPIN(PORT0,21,1);
		SetPIN(PORT0,23,1);
		SetPIN(PORT2,0,1);
	}
}

void Funciones_segundos(void)
{
	if(GetPIN(PORT0,28))
	{
		SetPIN(PORT0,28,0);
	}
	else
	{
		SetPIN(PORT0,28,1);
	}
}

void Funciones_minutos(void)
{

}

void Funciones_horas(void)
{

}

void Funciones_dias(void)
{

}
