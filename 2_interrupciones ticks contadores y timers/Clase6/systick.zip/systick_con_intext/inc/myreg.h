#define 	__RW				volatile
typedef 	unsigned int 		uint32_t;
typedef 	__RW uint32_t 		registro;
typedef 	unsigned char 		uint8_t;

#define	    PORT0 		( ( registro  * ) 0x2009C000UL )
#define	    PORT1		PORT0+8
#define	    PORT2		PORT0+16
#define	    PORT3		PORT0+24
#define	    PORT4		PORT0+32

#define		PINSEL		( ( registro  * ) 0x4002C000UL )
#define		PINSEL0		PINSEL[0]
#define		PINSEL1		PINSEL[1]
#define		PINSEL2		PINSEL[2]
#define		PINSEL3		PINSEL[3]
#define		PINSEL4		PINSEL[4]
#define		PINSEL5		PINSEL[5]
#define		PINSEL6		PINSEL[6]
#define		PINSEL7		PINSEL[7]
#define		PINSEL8		PINSEL[8]
#define		PINSEL9		PINSEL[9]

#define	 SysTick 		( (__RW uint32_t * )  0xE000E010UL  )
#define  STCTRL			SysTick[0]
#define  STRELOAD		SysTick[1]
#define  STCURR			SysTick[2]
#define  STCALIB		SysTick[3]

#define TMR_TICK		1000
#define CCLK			3000000


#define 	P0			0
#define 	P1			1
#define 	P2			2
#define 	P3			3
#define 	P4			4

#define 	SALIDA		1
#define		PINSEL_GPIO 0

#define	    EXTMODE 		*( ( registro  * ) 0x400FC148)
#define	    EXTPOLAR 		*( ( registro  * ) 0x400FC14C)
#define	    ISER0 			*( ( registro  * ) 0xE000E100)
#define	    ICER0 			*( ( registro  * ) 0xE000E180)
#define		EXTINT			*( ( registro  * ) 0x400FC140)

#define		INT_EXT		1

// PLL

//////////////Registros del CLOCK y de sistema/////////////////
//0x400FC1A0UL: Registro de control de sistema y registro de status:
#define		DIR_SCS			( (uint32_t *) 0x400FC1A0UL)
//0x400FC104UL: Registro de configuracion del clock:
#define		DIR_CCLKCFG		( (uint32_t *) 0x400FC104UL)
//0x400FC10CUL: Registro de seleccion del clock:
#define		DIR_CLKSRCSEL	( (uint32_t *) 0x400FC10CUL)
//0x400FC1C8UL: Clock Output Config register:
#define		DIR_CLKOUTCFG	( (uint32_t *) 0x400FC1C8UL)
//0x400FC000UL: Flash access configuration:
#define		DIR_FLASHCFG	( (uint32_t *) 0x400FC000UL)

/////////////////Registros de los PLL///////////////////////////
//0x400FC080UL: Registro de control del PLL0:
#define		DIR_PLL0CON		( (uint32_t *) 0x400FC080UL)
//0x400FC084UL: Registro de configuracion del PLL0:
#define		DIR_PLL0CFG		( (uint32_t *) 0x400FC084UL)
//0x400FC088UL: Registro de estado del PLL0:
#define		DIR_PLL0STAT	( (uint32_t *) 0x400FC088UL)
//0x400FC08CUL: Registro de control del PLL0:
#define		DIR_PLL0FEED	( (uint32_t *) 0x400FC08CUL)
//0x400FC0A0UL: Registro de control del PLL1:
#define		DIR_PLL1CON		( (uint32_t *) 0x400FC0A0UL)
//0x400FC0A4UL: Registro de configuracion del PLL1:
#define		DIR_PLL1CFG		( (uint32_t *) 0x400FC0A4UL)
//0x400FC0A8UL: Registro de estado del PLL1:
#define		DIR_PLL1STAT	( (uint32_t *) 0x400FC0A8UL)
//0x400FC0ACUL: Registro de control del PLL1:
#define		DIR_PLL1FEED	( (uint32_t *) 0x400FC0ACUL)

//Registro de status y configuracion del sistema:
#define		SCS			DIR_SCS[0]
#define 	FLASHCFG	DIR_FLASHCFG[0]

//Registros de control del CLOCK:
#define		CCLKCFG		DIR_CCLKCFG[0]
#define		CLKSRCSEL	DIR_CLKSRCSEL[0]
#define		CLKOUTCFG	DIR_CLKOUTCFG[0]

//PLL0:
#define		PLL0CON		DIR_PLL0CON[0]
#define		PLL0CFG		DIR_PLL0CFG[0]
#define		PLL0STAT	DIR_PLL0STAT[0]
#define		PLL0FEED	DIR_PLL0FEED[0]

//PLL1:
#define		PLL1CON		DIR_PLL1CON[0]
#define		PLL1CFG		DIR_PLL1CFG[0]
#define		PLL1STAT	DIR_PLL1STAT[0]
#define		PLL1FEED	DIR_PLL1FEED[0]
// Regs
#define		PCLKSEL		( ( registro  * ) 0x400FC1A8UL )
//!< Registros PCLKSEL
#define		PCLKSEL0	PCLKSEL[0]
#define		PCLKSEL1	PCLKSEL[1]
//Power on peripherials
#define 	PCONP	(* ( ( registro  * ) 0x400FC0C4UL ))
// Constantes
#define CLOCK_SETUP_Value 	    1
#define SCS_Value				0x00000020
#define CLKSRCSEL_Value         0x00000001
#define PLL0_SETUP_Value        1
#define PLL0CFG_Value           0x00050063
#define PLL1_SETUP_Value        1
#define PLL1CFG_Value           0x00000023
#define CCLKCFG_Value           0x00000003
#define USBCLKCFG_Value         0x00000000
#define PCLKSEL0_Value          0x00000000
#define PCLKSEL1_Value          0x00000000
#define PCONP_Value             0x042887DE
#define CLKOUTCFG_Value         0x00000000
#define FLASHCFG_Value			0x00004000
//Prototipos
void Init_systick(void);
void Init_gpios(void);
void SetPINSEL (uint8_t puerto, uint8_t pin, uint8_t modo);
void SetDIR(registro* puerto,uint8_t pin,uint8_t direccion);
void SetPIN(registro* puerto,uint8_t pin,uint8_t estado);
uint8_t GetPIN(registro* puerto,uint8_t pin);
void init(void);
void Init_intext(void);
void Funciones_decimas(void);
void Funciones_segundos(void);
void Funciones_minutos(void);
void Funciones_horas(void);
void Funciones_dias(void);
void Init_PLL(void);
