
#include <cr_section_macros.h>
#include <NXP/crp.h>
#include "myreg.h"

int main(void)
	{
	init();

	while(1)
	{
	}

	return 0 ;
	}
